words   = {'jass%.common'}
configs = {
    {
        name  = 'Lua.runtime.version',
        type  = 'set',
        value = 'Lua 5.3',
    },
}
